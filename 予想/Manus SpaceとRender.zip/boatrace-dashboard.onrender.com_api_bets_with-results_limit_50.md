
**URL:** https://boatrace-dashboard.onrender.com/api/bets/with-results?limit=50

---

(Content truncated due to size limit. Use line ranges to read remaining content)