            for p in payoffs:
                bet_type = p['bet_type']
                if bet_type not in payoffs_by_type:
                    payoffs_by_type[bet_type] = {
                        'name': bet_type_names.get(bet_type, bet_type),
                        'items': []
                    }
                payoffs_by_type[bet_type]['items'].append({
                    'combination': p['combination'],
                    'payout': p['payout'],
                    'popularity': p['popularity']
                })
            
            return {
                'race_date': race_date,
                'stadium_code': stadium_code,
                'stadium_name': stadium_name,
                'race_no': race_no,
                'results': [{
                    'boat_no': r['boat_no'],
                    'racer_no': r['racer_no'],
                    'rank': r['rank'],
                    'race_time': r['race_time']
                } for r in results],
                'payoffs': payoffs_by_type,
                'programs': [decimal_to_float(dict(p)) for p in programs]
            }
    finally:
        conn.close()


@app.get("/api/historical/dates")
def get_available_dates(limit: int = Query(default=30, le=365)):
    """
    データが存在する日付一覧を取得（最新から指定件数）
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT DISTINCT race_date
                FROM historical_race_results
                ORDER BY race_date DESC
                LIMIT %s
            """, (limit,))
            rows = cur.fetchall()
            
            # YYYYMMDD形式をYYYY-MM-DD形式に変換
            dates = []
            for row in rows:
                date_str = row['race_date']
                if len(date_str) == 8:
                    formatted = f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:8]}"
                    dates.append(formatted)
            
            return dates
    finally:
        conn.close()


# ==================== 管理API ====================

@app.post("/api/admin/update-skip-reasons")
def update_skip_reasons():
    """
    skipReasonが設定されていない見送りレースに一括で理由を設定
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            # skipReasonが設定されていない見送りレースを取得
            cur.execute("""
                SELECT id, reason FROM virtual_bets 
                WHERE status = 'skipped'
            """)
            skipped_bets = cur.fetchall()
            
            updated_count = 0
            for bet in skipped_bets:
                reason = {}
                if bet['reason']:
                    try:
                        if isinstance(bet['reason'], str):
                            reason = json.loads(bet['reason'])
                        elif isinstance(bet['reason'], dict):
                            reason = bet['reason']
                    except:
                        pass
                
                # skipReasonが設定されていない場合のみ更新
                if 'skipReason' not in reason:
                    reason['skipReason'] = '締切超過（購入判断未実行）'
                    reason['decision'] = 'skipped'
                    
                    cur.execute("""
                        UPDATE virtual_bets 
                        SET reason = %s
                        WHERE id = %s
                    """, (json.dumps(reason, ensure_ascii=False), bet['id']))
                    updated_count += 1