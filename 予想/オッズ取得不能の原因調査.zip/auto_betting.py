    try:
        url = f'https://www.boatrace.jp/owpc/pc/race/raceindex?jcd={stadium_code:02d}&hd={target_date.strftime("%Y%m%d")}'
        response = requests.get(url, timeout=30)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 各レースの行を探す
        race_rows = soup.select('table tr')
        for row in race_rows:
            cells = row.select('td')
            if len(cells) >= 2:
                race_text = cells[0].text.strip()
                time_text = cells[1].text.strip()
                
                # レース番号を抽出
                race_match = re.match(r'(\d+)R', race_text)
                if race_match:
                    race_num = int(race_match.group(1))
                    # 時刻を抽出
                    time_match = re.match(r'(\d{1,2}):(\d{2})', time_text)
                    if time_match:
                        hour = int(time_match.group(1))
                        minute = int(time_match.group(2))
                        deadline = target_date.replace(
                            hour=hour, minute=minute, second=0, microsecond=0,
                            tzinfo=JST
                        )
                        deadlines[race_num] = deadline
        
        logger.info(f"場{stadium_code}: {len(deadlines)}件の締切時刻を取得")
    except Exception as e:
        logger.warning(f"締切時刻取得エラー (場:{stadium_code}): {e}")
    
    return deadlines


def save_races_to_db(races: List[Dict[str, Any]]) -> int:
    """レース情報をDBに保存"""
    if not races:
        return 0
    
    conn = get_db_connection()
    saved_count = 0
    
    try:
        with conn.cursor() as cur:
            # 既存のレースIDを先に取得
            race_keys = [(r['race_date'], r['stadium_code'], r['race_number']) for r in races]
            
            cur.execute(
                "SELECT id, race_date, stadium_code, race_number FROM races WHERE (race_date, stadium_code, race_number) IN %s",