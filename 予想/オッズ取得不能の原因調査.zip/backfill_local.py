#!/usr/bin/env python3
"""
2026年1月17日以降の欠落データ（登番、タイム）を補正するスクリプト
ローカルで直接実行
"""

import psycopg2
from psycopg2.extras import RealDictCursor
import requests
from bs4 import BeautifulSoup
import re
import time
from datetime import datetime, timedelta

# DB接続情報
DATABASE_URL = "postgresql://kokotomo_db_staging_user:2hbJKGrCOqLqLcXNaT5NqVLVOyPqZuNB@dpg-ctds0qlumphs73a6qnfg-a.singapore-postgres.render.com/kokotomo_db_staging"

def get_db_connection():
    """DB接続を取得"""
    return psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor)

def backfill_date(conn, date_str, stadium_codes):
    """1日分のデータを補正"""
    processed = 0
    inserted = 0
    
    with conn.cursor() as cur:
        for stadium_code in stadium_codes:
            for race_no in range(1, 13):
                race_no_str = str(race_no).zfill(2)
                
                # 既存データをチェック
                cur.execute("""
                    SELECT COUNT(*) as cnt FROM historical_race_results
                    WHERE race_date = %s AND stadium_code = %s AND race_no = %s
                """, (date_str, stadium_code, race_no_str))
                if cur.fetchone()['cnt'] > 0:
                    continue  # 既存データがあればスキップ
                
                # 公式サイトから結果を取得
                url = f"https://www.boatrace.jp/owpc/pc/race/raceresult?rno={race_no}&jcd={stadium_code}&hd={date_str}"
                try:
                    resp = requests.get(url, timeout=10)
                    if resp.status_code != 200:
                        continue
                    
                    soup = BeautifulSoup(resp.text, 'html.parser')
                    
                    # 着順テーブルを探す
                    result_table = soup.find('table', class_='is-w495')
                    if not result_table:
                        continue
                    
                    tbody = result_table.find('tbody')
                    if not tbody:
                        continue
                    
                    rows = tbody.find_all('tr')
                    for row in rows:
                        cells = row.find_all('td')
                        if len(cells) < 4:
                            continue
                        
                        # 着順
                        rank = cells[0].get_text(strip=True)
                        
                        # 艇番
                        boat_no_elem = cells[1].find('span')
                        boat_no = boat_no_elem.get_text(strip=True) if boat_no_elem else ''
                        
                        # 登番（4桁数字）
                        racer_text = cells[2].get_text(strip=True)
                        racer_no_match = re.match(r'(\d{4})', racer_text)
                        racer_no = racer_no_match.group(1) if racer_no_match else ''
                        
                        # タイム
                        race_time = cells[3].get_text(strip=True)
                        
                        if boat_no and rank:
                            cur.execute("""
                                INSERT INTO historical_race_results 
                                (race_date, stadium_code, race_no, boat_no, racer_no, rank, race_time)
                                VALUES (%s, %s, %s, %s, %s, %s, %s)
                                ON CONFLICT (race_date, stadium_code, race_no, boat_no) DO UPDATE
                                SET racer_no = EXCLUDED.racer_no, race_time = EXCLUDED.race_time
                            """, (date_str, stadium_code, race_no_str, boat_no, racer_no, rank, race_time))
                            inserted += 1
                    
                    processed += 1
                    time.sleep(0.1)  # レート制限
                    
                except Exception as e:
                    print(f"  エラー: {date_str}/{stadium_code}/{race_no}: {e}")
                    continue
    
    return processed, inserted

def main():
    print("=== 欠落データ補正開始 ===")
    print(f"開始時刻: {datetime.now()}")
    
    # 補正期間
    start_date = datetime(2026, 1, 17).date()
    end_date = datetime(2026, 1, 23).date()
    
    conn = get_db_connection()
    
    try:
        # 競艇場コードを取得
        with conn.cursor() as cur:
            cur.execute("SELECT stadium_code FROM stadiums")
            stadium_codes = [str(row['stadium_code']).zfill(2) for row in cur.fetchall()]
        
        print(f"競艇場数: {len(stadium_codes)}")
        
        total_processed = 0
        total_inserted = 0
        
        current_date = start_date
        while current_date <= end_date:
            date_str = current_date.strftime("%Y%m%d")
            print(f"\n処理中: {date_str}")
            
            processed, inserted = backfill_date(conn, date_str, stadium_codes)
            conn.commit()
            
            total_processed += processed
            total_inserted += inserted
            print(f"  処理レース: {processed}, 挿入レコード: {inserted}")
            
            current_date += timedelta(days=1)
        
        print(f"\n=== 補正完了 ===")
        print(f"終了時刻: {datetime.now()}")
        print(f"処理レース合計: {total_processed}")
        print(f"挿入レコード合計: {total_inserted}")
        
    finally:
        conn.close()

if __name__ == "__main__":
    main()
