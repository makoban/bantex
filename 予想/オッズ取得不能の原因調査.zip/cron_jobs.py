"""
競艇データ収集システム - Cron Job エントリポイント
Renderのスケジュールジョブから呼び出されるスクリプトです。
"""

import os
import sys
import logging
from datetime import datetime, timedelta, timezone

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 日本時間
JST = timezone(timedelta(hours=9))

# 運用時間設定
OPERATION_START_HOUR = 8   # 8:00 JST
OPERATION_END_HOUR = 21    # 21:30 JST
OPERATION_END_MINUTE = 30


def is_within_operation_hours() -> bool:
    """
    運用時間内かどうかをチェック
    運用時間: 8:00〜21:30 JST
    """
    now_jst = datetime.now(JST)
    
    # 8:00前は運用時間外
    if now_jst.hour < OPERATION_START_HOUR:
        return False
    
    # 21:30以降は運用時間外
    if now_jst.hour > OPERATION_END_HOUR:
        return False
    if now_jst.hour == OPERATION_END_HOUR and now_jst.minute > OPERATION_END_MINUTE:
        return False
    
    return True


def get_database_url():
    """データベースURLを取得"""
    url = os.environ.get('DATABASE_URL')
    if not url:
        logger.error("DATABASE_URL環境変数が設定されていません")
        sys.exit(1)
    return url


def job_daily_collection():
    """
    日次収集ジョブ
    毎朝8:00 JSTに実行。当日の全レース情報と初期オッズを収集。
    """
    from collector import run_daily_collection
    
    logger.info("=== 日次収集ジョブ開始 ===")
    database_url = get_database_url()
    
    try:
        run_daily_collection(database_url)
        logger.info("=== 日次収集ジョブ完了 ===")
    except Exception as e:
        logger.error(f"日次収集ジョブ失敗: {e}")
        sys.exit(1)


def job_odds_collection_regular():
    """
    定期オッズ収集ジョブ
    10分ごとに実行。未終了レースのオッズを収集。
    """
    from collector import run_odds_regular_collection
    
    logger.info("=== 定期オッズ収集ジョブ開始 ===")
    database_url = get_database_url()
    
    try:
        run_odds_regular_collection(database_url)
        logger.info("=== 定期オッズ収集ジョブ完了 ===")
    except Exception as e:
        logger.error(f"定期オッズ収集ジョブ失敗: {e}")
        sys.exit(1)


def job_odds_collection_high_freq():
    """
    高頻度オッズ収集ジョブ
    締切5分前のレースのオッズを10秒間隔で収集。
    
    仕様（確定）:
    - 3連単・3連複は使わない
    - 2連単・2連複・単勝・複勝のみ
    - 締切5分前から10秒間隔で収集
    - 通常は10分間隔
    - レース開催日のみ稼働（毎朝チェック）
    - 運用時間: 8:00〜21:30 JST
    """
    logger.info("=== 高頻度オッズ収集ジョブ開始 ===")
    
    # 運用時間チェック
    if not is_within_operation_hours():
        now_jst = datetime.now(JST)
        logger.info(f"運用時間外のためスキップ (現在: {now_jst.strftime('%H:%M')} JST, 運用時間: {OPERATION_START_HOUR}:00〜{OPERATION_END_HOUR}:{OPERATION_END_MINUTE:02d})")
        logger.info("=== 高頻度オッズ収集ジョブ完了 ===")
        return
    
    from collect_odds import OddsCollector
    
    database_url = get_database_url()
    
    try:
        collector = OddsCollector(database_url)
        # 締切5分以内のレースを取得し、9回（10秒×9=90秒）収集
        collector.collect_near_deadline_races(minutes_before=5, interval_seconds=10, iterations=9)
        logger.info("=== 高頻度オッズ収集ジョブ完了 ===")
    except Exception as e:
        logger.error(f"高頻度オッズ収集ジョブ失敗: {e}")
        sys.exit(1)


def job_result_collection():
    """
    結果収集ジョブ
    15分ごとに実行。終了したレースの結果と払戻金を収集。
    
    追加機能（2026/01/19）:
    - 結果収集後にManus Space DBのvirtualBetsを更新
    - 過去3日分の結果も収集（未取得分のみ）
    """
    from collector import run_result_collection
    
    logger.info("=== 結果収集ジョブ開始 ===")
    database_url = get_database_url()
    
    try:
        # 今日と過去3日分の結果を収集
        for days_ago in range(4):  # 0, 1, 2, 3日前
            target_date = datetime.now(JST) - timedelta(days=days_ago)
            logger.info(f"結果収集対象日: {target_date.strftime('%Y-%m-%d')}")
            run_result_collection(database_url, target_date)
        
        # Manus Space DBの仮想購入結果を更新
        update_manus_virtual_bets(database_url)
        
        logger.info("=== 結果収集ジョブ完了 ===")
    except Exception as e:
        logger.error(f"結果収集ジョブ失敗: {e}")
        sys.exit(1)


def update_manus_virtual_bets(boatrace_db_url: str):
    """
    Manus Space DBのvirtualBetsを更新
    
    - confirmedステータスで結果未確定のレースを取得
    - 外部DBから結果を取得
    - 的中/不的中を判定してvirtualBetsを更新
    - 資金（virtualFunds）も更新
    """
    manus_db_url = os.environ.get('MANUS_DATABASE_URL')
    if not manus_db_url:
        logger.debug("MANUS_DATABASE_URL未設定、仮想購入結果更新をスキップ")
        return
    
    logger.info("=== Manus Space DB 仮想購入結果更新開始 ===")
    
    try:
        import pymysql
        from pymysql.cursors import DictCursor
        import psycopg2
        from psycopg2.extras import DictCursor as PgDictCursor
        import json
        import re
        
        # MySQL URL解析
        def parse_mysql_url(url: str) -> dict:
            pattern = r'mysql://([^:]+):([^@]+)@([^:/]+):?(\d+)?/([^?]+)(?:\?(.*))?'
            match = re.match(pattern, url)
            if not match:
                raise ValueError(f"Invalid MySQL URL: {url}")
            
            user, password, host, port, database, params = match.groups()
            
            config = {
                'host': host,
                'user': user,
                'password': password,
                'database': database,
                'port': int(port) if port else 4000,
                'charset': 'utf8mb4',
                'cursorclass': DictCursor,
            }
            
            if params and 'ssl' in params.lower():
                config['ssl'] = {'ssl': {}}
            
            return config
        
        # Manus Space DBに接続
        manus_config = parse_mysql_url(manus_db_url)
        manus_config['ssl'] = {'ssl': {}}
        manus_conn = pymysql.connect(**manus_config)
        
        # 外部DBに接続
        pg_conn = psycopg2.connect(boatrace_db_url)
        
        try:
            # confirmedステータスで結果未確定のレースを取得
            with manus_conn.cursor() as cursor:
                cursor.execute("""
                    SELECT * FROM virtualBets 
                    WHERE status = 'confirmed'
                    AND resultConfirmedAt IS NULL
                """)
                confirmed_bets = cursor.fetchall()
            
            if not confirmed_bets:
                logger.info("結果待ちの購入がありません")
                return
            
            logger.info(f"結果確認対象: {len(confirmed_bets)}件")
            
            for bet in confirmed_bets:
                try:
                    process_single_bet_result(bet, manus_conn, pg_conn)
                except Exception as e:
                    logger.error(f"結果処理エラー: bet_id={bet['id']}, error={e}")
        
        finally:
            manus_conn.close()
            pg_conn.close()
        
        logger.info("=== Manus Space DB 仮想購入結果更新完了 ===")
        
    except ImportError as e:
        logger.error(f"必要なモジュールがインストールされていません: {e}")
    except Exception as e:
        logger.error(f"Manus Space DB更新エラー: {e}")


def process_single_bet_result(bet: dict, manus_conn, pg_conn):
    """単一の購入結果を処理"""
    from psycopg2.extras import DictCursor as PgDictCursor
    import json
    
    bet_id = bet['id']
    strategy_type = bet['strategyType']
    race_date = bet['raceDate'].strftime('%Y%m%d') if hasattr(bet['raceDate'], 'strftime') else str(bet['raceDate']).replace('-', '')
    stadium_code = bet['stadiumCode']
    race_number = bet['raceNumber']
    combination = bet['combination']
    bet_type = bet['betType']
    bet_amount = float(bet['betAmount'])
    
    logger.info(f"結果確認: {stadium_code} {race_number}R {combination}")
    
    # 外部DBから結果を取得
    with pg_conn.cursor(cursor_factory=PgDictCursor) as cursor:
        # historical_race_resultsから結果を取得
        cursor.execute("""
            SELECT 
                hrr.stadium_code,
                hrr.race_no::integer as race_number,
                hrr.race_date,
                MAX(CASE WHEN hrr.rank IN ('1', '01') THEN hrr.boat_no::integer END) as rank1,
                MAX(CASE WHEN hrr.rank IN ('2', '02') THEN hrr.boat_no::integer END) as rank2,
                MAX(CASE WHEN hrr.rank IN ('3', '03') THEN hrr.boat_no::integer END) as rank3
            FROM historical_race_results hrr
            WHERE hrr.stadium_code = %s 
              AND hrr.race_no = %s
              AND hrr.race_date = %s
            GROUP BY hrr.stadium_code, hrr.race_no, hrr.race_date
        """, (stadium_code, str(race_number).zfill(2), race_date))
        result = cursor.fetchone()
        
        if not result:
            # race_resultsテーブルからも試す
            cursor.execute("""
                SELECT 
                    rr.first_place as rank1,
                    rr.second_place as rank2,
                    rr.third_place as rank3
                FROM race_results rr
                JOIN races r ON rr.race_id = r.id
                WHERE r.stadium_code = %s 
                  AND r.race_number = %s
                  AND r.race_date = %s
            """, (int(stadium_code), race_number, race_date.replace('/', '-') if '/' in race_date else f"{race_date[:4]}-{race_date[4:6]}-{race_date[6:8]}"))
            result = cursor.fetchone()
        
        if not result or not result['rank1']:
            logger.info(f"レース結果未確定: {stadium_code} {race_number}R")
            return
        
        # 的中判定
        actual_result = str(result['rank1'])
        is_hit = False
        payoff = 0
        
        if bet_type == 'win':
            # 単勝の場合
            is_hit = (combination == actual_result)
            if is_hit:
                # 払戻金を取得
                cursor.execute("""
                    SELECT payoff FROM payoffs p
                    JOIN races r ON p.race_id = r.id
                    WHERE r.stadium_code = %s 
                      AND r.race_number = %s
                      AND r.race_date = %s
                      AND p.bet_type = 'win'
                """, (int(stadium_code), race_number, f"{race_date[:4]}-{race_date[4:6]}-{race_date[6:8]}"))
                payoff_row = cursor.fetchone()
                if payoff_row:
                    payoff = float(payoff_row['payoff'])
        
        elif bet_type == 'quinella':
            # 2連複の場合
            result_combo = f"{min(result['rank1'], result['rank2'])}-{max(result['rank1'], result['rank2'])}"
            actual_result = result_combo
            is_hit = (combination == result_combo)
            if is_hit:
                cursor.execute("""
                    SELECT payoff FROM payoffs p
                    JOIN races r ON p.race_id = r.id
                    WHERE r.stadium_code = %s 
                      AND r.race_number = %s
                      AND r.race_date = %s
                      AND p.bet_type = 'quinella'
                      AND p.combination = %s
                """, (int(stadium_code), race_number, f"{race_date[:4]}-{race_date[4:6]}-{race_date[6:8]}", combination))
                payoff_row = cursor.fetchone()
                if payoff_row:
                    payoff = float(payoff_row['payoff'])
        
        elif bet_type == 'exacta':
            # 2連単の場合
            result_combo = f"{result['rank1']}-{result['rank2']}"
            actual_result = result_combo
            is_hit = (combination == result_combo)
            if is_hit:
                cursor.execute("""
                    SELECT payoff FROM payoffs p
                    JOIN races r ON p.race_id = r.id
                    WHERE r.stadium_code = %s 
                      AND r.race_number = %s
                      AND r.race_date = %s
                      AND p.bet_type = 'exacta'
                      AND p.combination = %s
                """, (int(stadium_code), race_number, f"{race_date[:4]}-{race_date[4:6]}-{race_date[6:8]}", combination))
                payoff_row = cursor.fetchone()
                if payoff_row:
                    payoff = float(payoff_row['payoff'])
    
    # 回収額と損益を計算
    return_amount = (payoff / 100 * bet_amount) if is_hit else 0
    profit = return_amount - bet_amount
    
    # Manus Space DBを更新
    now = datetime.now(JST)
    status = 'won' if is_hit else 'lost'
    
    with manus_conn.cursor() as cursor:
        # virtualBetsを更新
        cursor.execute("""
            UPDATE virtualBets 
            SET status = %s,
                actualResult = %s,
                payoff = %s,
                returnAmount = %s,
                profit = %s,
                resultConfirmedAt = %s,
                updatedAt = %s
            WHERE id = %s
        """, (status, actual_result, payoff, return_amount, profit, now, now, bet_id))
        
        # virtualFundsを更新
        cursor.execute("""
            SELECT * FROM virtualFunds 
            WHERE strategyType = %s AND isActive = 1
            LIMIT 1
        """, (strategy_type,))
        fund = cursor.fetchone()
        
        if fund:
            current_fund = float(fund['currentFund']) + profit
            total_profit = float(fund['totalProfit']) + profit
            total_bets = fund['totalBets'] + 1
            total_hits = fund['totalHits'] + (1 if is_hit else 0)
            hit_rate = (total_hits / total_bets * 100) if total_bets > 0 else 0
            
            total_bet_amount = float(fund['totalBetAmount']) + bet_amount
            total_return_amount = float(fund['totalReturnAmount']) + return_amount
            return_rate = (total_return_amount / total_bet_amount * 100) if total_bet_amount > 0 else 0
            
            cursor.execute("""
                UPDATE virtualFunds 
                SET currentFund = %s,
                    totalProfit = %s,
                    totalBets = %s,
                    totalHits = %s,
                    hitRate = %s,
                    totalBetAmount = %s,
                    totalReturnAmount = %s,
                    returnRate = %s,
                    updatedAt = %s
                WHERE id = %s
            """, (current_fund, total_profit, total_bets, total_hits, hit_rate,
                  total_bet_amount, total_return_amount, return_rate, now, fund['id']))
        
        manus_conn.commit()
    
    logger.info(f"結果更新完了: bet_id={bet_id}, status={status}, profit={profit}")


def job_betting_process():
    """
    購入判断ジョブ
    1分ごとに実行。締切1分前のレースの購入判断を行う。
    
    処理内容:
    1. 締切1分前のpendingレースを取得
    2. 最新オッズを確認
    3. 条件を満たせばconfirmed、満たさなければskipped
    4. 締切超過のpendingレースをskippedに更新
    """
    from virtual_betting import VirtualBettingManager
    
    logger.info("=== 購入判断ジョブ開始 ===")
    
    # 運用時間チェック
    if not is_within_operation_hours():
        now_jst = datetime.now(JST)
        logger.info(f"運用時間外のためスキップ (現在: {now_jst.strftime('%H:%M')} JST)")
        logger.info("=== 購入判断ジョブ完了 ===")
        return
    
    database_url = get_database_url()
    
    try:
        manager = VirtualBettingManager(database_url)
        
        # 締切1分前のレースの購入判断を実行
        manager.process_deadline_bets()
        
        # 締切超過のレースを見送りに更新
        expired_count = manager.expire_overdue_bets()
        logger.info(f"締切超過で見送りにしたレース: {expired_count}件")
        
        logger.info("=== 購入判断ジョブ完了 ===")
    except Exception as e:
        logger.error(f"購入判断ジョブ失敗: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


def job_test():
    """
    テストジョブ
    デプロイ確認用。DB接続をテストして終了。
    """
    import psycopg2
    
    logger.info("=== テストジョブ開始 ===")
    database_url = get_database_url()
    
    try:
        conn = psycopg2.connect(database_url)
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM stadiums")
            count = cur.fetchone()[0]
            logger.info(f"stadiumsテーブルのレコード数: {count}")
            
            cur.execute("SELECT NOW()")
            db_time = cur.fetchone()[0]
            logger.info(f"データベース時刻: {db_time}")
            
        conn.close()
        logger.info("=== テストジョブ完了: DB接続成功 ===")
    except Exception as e:
        logger.error(f"テストジョブ失敗: {e}")
        sys.exit(1)


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python cron_jobs.py <job_name>")
        print("Available jobs: daily, odds_regular, odds_high_freq, result, betting, test")
        sys.exit(1)
        
    job_name = sys.argv[1]
    
    jobs = {
        'daily': job_daily_collection,
        'odds_regular': job_odds_collection_regular,
        'odds_high_freq': job_odds_collection_high_freq,
        'result': job_result_collection,
        'betting': job_betting_process,
        'test': job_test,
    }
    
    if job_name not in jobs:
        logger.error(f"不明なジョブ名: {job_name}")
        print(f"Available jobs: {', '.join(jobs.keys())}")
        sys.exit(1)
        
    jobs[job_name]()
