# デプロイ状況 - 2026-01-23 16:40

## 最新のデプロイ

**Deploy started for 301a559: fix: race_date型不一致を修正 - VARCHAR vs DATE (v8.11)**
- 時刻: January 23, 2026 at 7:39 AM (UTC) = 16:39 JST
- 状態: **デプロイ中**

## 修正内容

- get_all_pending_bets_near_deadline: JOIN条件で`race_date::text`に変換
- process_expired_bets: 同様にJOIN条件を修正
- 原因: virtual_bets.race_date(VARCHAR) vs races.race_date(DATE)の型不一致
