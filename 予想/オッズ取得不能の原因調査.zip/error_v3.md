# まだエラーが出ている - 2026-01-23 16:45

## エラーメッセージ

```
ERROR - 締切間近購入取得エラー: operator does not exist: date = text
LINE 4: JOIN races r ON vb.race_date = r.race_da...
HINT: No operator matches the given name and argument types. You might need to add explicit type casts.
```

## 問題

古いインスタンス [s8mrc] がまだ動いている！

新しいインスタンス [gpdv4] がデプロイされたが、古いインスタンスがまだ処理を行っている。

## 確認事項

1. 古いインスタンス [s8mrc] は v8.11 のコード（間違った修正）
2. 新しいインスタンス [gpdv4] は v8.12 のコード（正しい修正）

新しいインスタンスからの仮想購入処理ログを待つ必要がある。
