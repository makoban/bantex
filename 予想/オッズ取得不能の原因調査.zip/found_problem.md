# 発見した問題 - 2026-01-23

## 問題の特定

**virtual_betsテーブルのカラム名は `race_date`, `stadium_code`, `race_number`（スネークケース）です！**

INSERT文を確認：
```sql
INSERT INTO virtual_bets (
    race_date, stadium_code, race_number, strategy_type,
    combination, bet_type, amount, status, reason, created_at
) VALUES ...
```

## get_all_pending_bets_near_deadlineメソッドのSQL

```sql
SELECT vb.*, r.deadline_at
FROM virtual_bets vb
JOIN races r ON vb.race_date = r.race_date 
    AND CAST(vb.stadium_code AS smallint) = r.stadium_code 
    AND vb.race_number = CAST(r.race_number AS integer)
WHERE vb.status = 'pending'
AND r.deadline_at <= %s
AND r.deadline_at > %s
ORDER BY r.deadline_at
```

## 問題点

SQLは正しいスネークケースを使用しています。

**では、なぜ「処理対象の購入予定がありません」になるのか？**

## 可能性

1. **時刻の比較が問題**
   - `r.deadline_at <= deadline_threshold` (締切が現在+1分以内)
   - `r.deadline_at > now_utc` (締切がまだ来ていない)
   
   締切16:32のレースは、16:33の時点ではすでに `r.deadline_at > now_utc` を満たさない！

2. **つまり、締切を過ぎたレースは取得されない**
   - これは正しい動作だが、締切を過ぎたレースは「期限切れ」として処理されるべき

## 確認すべきこと

1. `process_expired_bets`メソッドが正しく動作しているか
2. 期限切れの購入予定が正しく処理されているか
