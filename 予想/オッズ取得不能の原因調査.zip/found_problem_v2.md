# 問題を特定！

## 現在のSQL

```sql
SELECT vb.*, r.deadline_at
FROM virtual_bets vb
JOIN races r ON vb.race_date::date = r.race_date 
    AND CAST(vb.stadium_code AS smallint) = r.stadium_code 
    AND vb.race_number = CAST(r.race_number AS integer)
WHERE vb.status = 'pending'
AND r.deadline_at <= %s
AND r.deadline_at > %s
ORDER BY r.deadline_at
```

## 問題点

**deadline_atの条件が逆になっている！**

現在の条件：
- `r.deadline_at <= deadline_threshold` (締切が現在+1分以内)
- `r.deadline_at > now_utc` (締切が現在より後)

これは「現在から1分以内に締切を迎えるレース」を取得する条件で、**正しい**はずだが...

## 別の問題

**race_dateの形式が違う可能性**

- virtual_bets.race_date: 'YYYY-MM-DD' (例: '2026-01-23')
- races.race_date: DATE型

`vb.race_date::date` でキャストしているが、virtual_betsのrace_dateが 'YYYYMMDD' 形式（例: '20260123'）の場合、キャストが失敗する。

## 確認すべきこと

1. virtual_betsテーブルのrace_dateの実際の値を確認
2. racesテーブルのrace_dateの実際の値を確認
