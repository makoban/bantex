            
            # 着順データの検出
            if current_stadium and current_race_no:
                result_match = result_pattern.match(stripped)
                if result_match:
                    rank = result_match.group(1)
                    boat_no = result_match.group(2)
                    racer_no = result_match.group(3)
                    race_time = result_match.group(10).strip()
                    
                    # レースタイムが空の場合は ". ." を空文字に
                    if race_time in ['. .', '.  .', '']:
                        race_time = ''
                    
                    results.append({
                        'race_date': race_date,
                        'stadium_code': current_stadium,
                        'race_no': current_race_no,
                        'boat_no': boat_no,
                        'racer_no': racer_no,
                        'rank': rank,
                        'race_time': race_time
                    })
    
    except Exception as e:
        logger.error(f"ファイルパースエラー: {filepath} - {e}")
    
    return results


def parse_payoffs_from_result_file(filepath):
    """
    レース結果ファイル（Kファイル）から払戻金データをパース
    
    払戻金フォーマット:
    - 単勝     1          100
    - 複勝     1          100  2          110
    - ２連単   1-2        430  人気     2
    - ２連複   1-2        330  人気     2
    - 拡連複   1-2        180  人気     2 （ワイド、最大3組）