"""
LZHファイルからの結果取得バッチ処理

毎日6:00 JSTに実行され、前日の結果をLZHファイルから取得して
データベースに保存・検証します。
"""

import os
import sys
import logging
import requests
import psycopg2
import re
import lhafile
from datetime import datetime, timedelta, timezone
from typing import Optional, List, Dict

# ログ設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 日本時間
JST = timezone(timedelta(hours=9))

# ダウンロード先ディレクトリ
BASE_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')
RESULT_DOWNLOAD_DIR = os.path.join(BASE_DIR, 'race_results_lzh')
RESULT_EXTRACTED_DIR = os.path.join(BASE_DIR, 'race_results')

# 公式サイトのURL
RESULT_BASE_URL = "https://www1.mbrace.or.jp/od2/K"


def download_file(url: str, filepath: str, max_retries: int = 3) -> Optional[str]:
    """
    指定されたURLからファイルをダウンロード
    """
    for attempt in range(max_retries):
        try:
            response = requests.get(url, timeout=60)
            
            if response.status_code == 200:
                os.makedirs(os.path.dirname(filepath), exist_ok=True)
                with open(filepath, 'wb') as f:
                    f.write(response.content)
                logger.info(f"ダウンロード完了: {os.path.basename(filepath)} ({len(response.content)} bytes)")
                return filepath
            elif response.status_code == 404:
                logger.info(f"ファイルが存在しません: {url}")
                return None
            else:
                logger.warning(f"ダウンロード失敗: {url} (HTTP {response.status_code})")
                
        except Exception as e:
            logger.warning(f"ダウンロードエラー (試行 {attempt + 1}/{max_retries}): {url} - {e}")
    
    return None


def extract_lzh(filepath: str, output_dir: str) -> Optional[str]:
    """
    LZHファイルを解凍（Pythonライブラリを使用）
    """
    if not filepath or not os.path.exists(filepath):
        return None
    
    os.makedirs(output_dir, exist_ok=True)
    
    try:
        # lhafileライブラリで解凍
        with lhafile.LhaFile(filepath) as lha:
            for info in lha.infolist():
                # ファイル名を取得
                filename = info.filename
                # パスの区切り文字を正規化
                if '\\' in filename:
                    filename = filename.replace('\\', '/')
                # ディレクトリ部分を除去してファイル名のみ取得
                basename = os.path.basename(filename)
                if not basename:
                    continue
                
                # ファイルを解凍
                output_path = os.path.join(output_dir, basename)
                with open(output_path, 'wb') as f:
                    f.write(lha.read(info.filename))
                logger.debug(f"解凍: {basename}")
        
        logger.info(f"解凍完了: {os.path.basename(filepath)}")
        return output_dir
        
    except Exception as e:
        logger.error(f"解凍エラー: {os.path.basename(filepath)} - {e}")
        return None


def download_race_results_for_date(target_date: datetime) -> Optional[str]:
    """
    指定日の競走成績LZHファイルをダウンロード・解凍
    
    Returns:
        解凍先ディレクトリのパス、失敗時はNone
    """
    year = target_date.year
    month = target_date.month
    day = target_date.day
    
    # URLとファイルパスを生成
    yyyymm = f"{year:04d}{month:02d}"
    yymm = f"{year % 100:02d}{month:02d}"
    dd = f"{day:02d}"
    
    url = f"{RESULT_BASE_URL}/{yyyymm}/k{yymm}{dd}.lzh"
    filepath = os.path.join(RESULT_DOWNLOAD_DIR, yyyymm, f"k{yymm}{dd}.lzh")
    
    logger.info(f"LZHファイルダウンロード: {url}")
    
    downloaded = download_file(url, filepath)
    if downloaded:
        output_dir = os.path.join(RESULT_EXTRACTED_DIR, yyyymm)
        extracted = extract_lzh(downloaded, output_dir)
        return extracted
    
    return None


def parse_result_file(filepath: str) -> List[Dict]:
    """
    レース結果ファイル（Kファイル）をパース
    
    Kファイルのフォーマット:
    - テキストファイル（Shift-JIS）
    - 場コード: "24KBGN" 形式（先頭2桁が場コード）
    - レース番号: "   1R       予　選" 形式
    - 着順データ: "01  3 2778 河　内　正　一　 21   15  6.68   2    0.08     1.49.3"
    """
    results = []
    
    try:
        with open(filepath, 'rb') as f:
            content = f.read()
        
        # Shift-JISでデコード
        text = content.decode('shift_jis', errors='ignore')
        lines = text.replace('\r', '').split('\n')
        
        # ファイル名から日付を取得 (K260123.TXT -> 20260123)
        basename = os.path.basename(filepath).upper()
        race_date = None
        if basename.startswith('K') and len(basename) >= 7:
            date_part = basename[1:7]  # 260123
            try:
                year = int(date_part[:2])
                year = 2000 + year if year < 50 else 1900 + year
                month = date_part[2:4]
                day = date_part[4:6]
                race_date = f"{year}{month}{day}"
            except ValueError:
                pass
        
        if not race_date:
            logger.warning(f"ファイル名から日付を取得できません: {filepath}")
            return results
        
        # 状態変数
        current_stadium = None
        current_race_no = None
        
        # 着順データ行のパターン
        result_pattern = re.compile(
            r'^\s*(\d{2}|[FKLSE失転落沈妨欠])\s+'  # 着順
            r'(\d)\s+'                              # 艇番
            r'(\d{4})\s+'                           # 登番
        )
        
        # レース番号行のパターン（"   1R       予　選" 形式）
        race_pattern = re.compile(r'^\s*(\d{1,2})R\s+')
        
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            
            # 場コードの検出 (24KBGN形式)
            if 'KBGN' in line:
                match = re.search(r'(\d{2})KBGN', line)
                if match:
                    current_stadium = match.group(1)
                continue
            
            # レース番号の検出
            race_match = race_pattern.match(stripped)
            if race_match:
                current_race_no = race_match.group(1).zfill(2)
                continue
            
            # 着順データの検出
            if current_stadium and current_race_no:
                result_match = result_pattern.match(stripped)
                if result_match:
                    rank_str = result_match.group(1)
                    boat_no = result_match.group(2)
                    racer_no = result_match.group(3)
                    
                    # 着順を数値に変換（失格等は99）
                    try:
                        rank = int(rank_str)
                    except ValueError:
                        rank = 99  # 失格、転覆等
                    
                    results.append({
                        'race_date': race_date,
                        'stadium_code': current_stadium,
                        'race_no': current_race_no,
                        'boat_no': boat_no,
                        'rank': f"{rank:02d}",
                        'racer_no': racer_no
                    })
        
        logger.info(f"パース完了: {filepath} -> {len(results)}件")
        
    except Exception as e:
        logger.error(f"ファイルパースエラー: {filepath} - {e}")
    
    return results


def save_results_to_db(results: List[Dict], database_url: str) -> int:
    """
    パースした結果をデータベースに保存
    
    Returns:
        保存した件数
    """
    if not results:
        return 0
    
    saved_count = 0
    
    try:
        conn = psycopg2.connect(database_url)
        
        with conn.cursor() as cur:
            for result in results:
                try:
                    cur.execute("""
                        INSERT INTO historical_race_results 
                        (race_date, stadium_code, race_no, boat_no, rank)
                        VALUES (%s, %s, %s, %s, %s)
                        ON CONFLICT (race_date, stadium_code, race_no, boat_no) DO UPDATE SET
                            rank = EXCLUDED.rank
                    """, (
                        result['race_date'],
                        result['stadium_code'],
                        result['race_no'],
                        result['boat_no'],
                        result['rank']
                    ))
                    saved_count += 1
                except Exception as e:
                    logger.warning(f"保存エラー: {result} - {e}")
            
            conn.commit()
        
        conn.close()
        logger.info(f"データベースに保存: {saved_count}件")
        
    except Exception as e:
        logger.error(f"データベース接続エラー: {e}")
    
    return saved_count


def verify_results(target_date: datetime, database_url: str) -> Dict:
    """
    スクレイピング結果とLZH結果を比較・検証
    
    Returns:
        検証結果の辞書
    """
    date_str = target_date.strftime('%Y%m%d')
    
    verification = {
        'date': date_str,
        'scraping_count': 0,
        'lzh_count': 0,
        'match_count': 0,
        'mismatch_count': 0,
        'missing_in_scraping': 0,
        'missing_in_lzh': 0
    }
    
    try:
        conn = psycopg2.connect(database_url)
        
        with conn.cursor() as cur:
            # スクレイピング結果（race_results）のカウント
            cur.execute("""
                SELECT COUNT(*) FROM race_results rr
                JOIN races r ON rr.race_id = r.id
                WHERE r.race_date = %s::date
            """, (target_date.strftime('%Y-%m-%d'),))
            verification['scraping_count'] = cur.fetchone()[0]
            
            # LZH結果（historical_race_results）のカウント
            cur.execute("""
                SELECT COUNT(*) FROM historical_race_results
                WHERE race_date = %s
            """, (date_str,))
            verification['lzh_count'] = cur.fetchone()[0]
        
        conn.close()
        
        logger.info(f"検証結果: スクレイピング={verification['scraping_count']}件, LZH={verification['lzh_count']}件")
        
    except Exception as e:
        logger.error(f"検証エラー: {e}")
    
    return verification


def run_morning_batch(database_url: str = None):
    """
    早朝バッチ処理のメイン関数
    前日の結果をLZHファイルから取得してデータベースに保存
    """
    logger.info("=== LZH結果取得バッチ処理開始 ===")
    
    if not database_url:
        database_url = os.environ.get('DATABASE_URL')
    
    if not database_url:
        logger.error("DATABASE_URLが設定されていません")
        return
    
    # 前日の日付を取得
    now_jst = datetime.now(JST)
    yesterday = now_jst - timedelta(days=1)
    
    logger.info(f"対象日: {yesterday.strftime('%Y-%m-%d')}")
    
    # LZHファイルをダウンロード・解凍
    extracted_dir = download_race_results_for_date(yesterday)
    
    if not extracted_dir:
        logger.warning("LZHファイルのダウンロードに失敗しました（まだ公開されていない可能性）")
        return
    
    # 解凍されたファイルを探す
    yymm = f"{yesterday.year % 100:02d}{yesterday.month:02d}"
    dd = f"{yesterday.day:02d}"
    result_filename = f"K{yymm}{dd}.TXT"
    result_filepath = os.path.join(extracted_dir, result_filename)
    
    # 大文字小文字の違いを考慮
    if not os.path.exists(result_filepath):
        result_filepath = os.path.join(extracted_dir, result_filename.lower())
    
    if not os.path.exists(result_filepath):
        # ディレクトリ内のファイルを探す
        for f in os.listdir(extracted_dir):
            if f.upper() == result_filename:
                result_filepath = os.path.join(extracted_dir, f)
                break
    
    if not os.path.exists(result_filepath):
        logger.warning(f"結果ファイルが見つかりません: {result_filename}")
        return
    
    # ファイルをパース
    results = parse_result_file(result_filepath)
    
    if not results:
        logger.warning("パース結果が空です")
        return
    
    # データベースに保存
    saved_count = save_results_to_db(results, database_url)
    
    # 検証
    verification = verify_results(yesterday, database_url)
    
    logger.info(f"=== LZH結果取得バッチ処理完了: {saved_count}件保存 ===")
    
    return {
        'date': yesterday.strftime('%Y-%m-%d'),
        'saved_count': saved_count,
        'verification': verification
    }


if __name__ == '__main__':
    # 直接実行時のテスト
    run_morning_batch()
