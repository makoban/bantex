# 新しいインスタンス [upodc] のログ - 2026-01-23 16:44

## デプロイ完了

新しいインスタンス [upodc] が起動しました。

## 起動ログ

```
=== Your service is live ===
=== Running 'cd boatrace-collector/src && python odds_worker.py' ===

2026-01-23 16:44:45,053 - INFO - === 競艇オッズ高頻度収集Worker起動 ===
2026-01-23 16:44:45,053 - INFO - 高頻度収集: 締切10秒前から5秒間隔
2026-01-23 16:44:45,053 - INFO - 通常収集: 1回/5秒
2026-01-23 16:44:45,053 - INFO - 結果収集: 30秒間隔
2026-01-23 16:44:45,053 - INFO - 仮想購入: 5分間隔
2026-01-23 16:44:45,053 - INFO - 運用時間: 8:00〜21:30 JST
2026-01-23 16:44:45,053 - INFO - DATABASE_URL: 設定済み
2026-01-23 16:44:45,054 - INFO - 仮想購入機能: 有効 (PostgreSQL使用)
2026-01-23 16:44:45,142 - INFO - === 既存の未処理ベット(skipReason更新前) ===
2026-01-23 16:44:45,171 - INFO - 既存ベット数: 32件
2026-01-23 16:44:45,171 - INFO - - skipReason更新完了: 0件
2026-01-23 16:44:45,173 - INFO - Adding job tentatively -- it will be properly scheduled when the scheduler starts
2026-01-23 16:44:45,174 - INFO - Added job "高頻度オッズ収集" to job store "default"
2026-01-23 16:44:45,174 - INFO - Added job "定期オッズ収集" to job store "default"
2026-01-23 16:44:45,174 - INFO - Added job "仮想購入処理" to job store "default"
2026-01-23 16:44:45,174 - INFO - Added job "レース結果収集" to job store "default"
2026-01-23 16:44:45,174 - INFO - Scheduler started
2026-01-23 16:44:45,174 - INFO - スケジューラを開始しました
2026-01-23 16:44:45,638 - INFO - === 定期オッズ収集開始 ===
```

## 状況

新しいバージョン (v8.12) がデプロイされました。次の仮想購入処理のログを確認します。
