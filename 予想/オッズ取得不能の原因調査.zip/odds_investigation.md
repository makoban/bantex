# オッズ取得不能の原因調査レポート

## 調査対象
- 1/23 平和島1R（締切10:45）- tansho_kanto戦略
- 1/23 尼崎1R（締切10:35）- bias_1_3_2nd戦略

## 問題の概要
両レースとも「オッズ取得失敗」で見送り（skipped）になっている。

## 調査結果

### 1. オッズデータの状況

#### 平和島1R
- **単勝オッズ**: 2号艇、3号艇、4号艇のみ存在。**1号艇のオッズが欠損**
- **最終収集時刻**: 10:22 JST（締切の約23分前）
- **購入判断時刻**: 10:43 JST

#### 尼崎1R
- **2連単/2連複オッズ**: 1-3の組み合わせは存在する（2t: 3.7, 2f: 2.4）
- **最終収集時刻**: 10:21 JST（締切の約14分前）
- **購入判断時刻**: 10:33 JST

### 2. 問題の原因

#### 平和島1R（tansho_kanto戦略）
**原因**: 1号艇の単勝オッズがodds_historyテーブルに保存されていない

- 公式サイトのHTMLパースは正常に動作している（現在のテストで6艇全てのオッズを取得可能）
- しかし、DBには2, 3, 4号艇のオッズしか保存されていない
- 1号艇のオッズが欠損している理由は不明（収集時のエラー、または特定条件でスキップされた可能性）

#### 尼崎1R（bias_1_3_2nd戦略）
**原因**: virtual_betting.pyのget_latest_oddsメソッドがbet_type='auto'を正しく処理していない

- odds_historyには1-3の2連単オッズ（3.7）と2連複オッズ（2.4）が存在する
- しかし、bet_type='auto'の場合、odds_type_mapで'win'に変換されてしまう
- 結果として、単勝オッズを検索してしまい、Noneが返される

### 3. コードの問題箇所

#### virtual_betting.py（556-578行目）
```python
def _process_single_bet(self, bet: Dict):
    ...
    # オッズタイプを変換
    odds_type_map = {'win': 'win', 'quinella': '2f', 'exacta': '2t'}
    odds_type = odds_type_map.get(bet_type, 'win')  # ← 'auto'は'win'になる
    
    # 最新オッズを取得
    final_odds = self.get_latest_odds(race_date, stadium_code, race_number, odds_type, combination)
```

**問題**: `bet_type='auto'`の場合、`odds_type_map.get('auto', 'win')`は`'win'`を返す。
しかし、bias_1_3戦略では2連単/2連複を使用するため、'2t'または'2f'を検索すべき。

## 修正案

### 修正1: bet_type='auto'の処理を追加
```python
def _process_single_bet(self, bet: Dict):
    ...
    # オッズタイプを変換
    if bet_type == 'auto':
        # 2連単と2連複の両方を取得し、高い方を選択
        odds_2t = self.get_latest_odds(race_date, stadium_code, race_number, '2t', combination)
        odds_2f = self.get_latest_odds(race_date, stadium_code, race_number, '2f', combination)
        
        if odds_2t is None and odds_2f is None:
            logger.warning(f"オッズ取得失敗: {stadium_code} {race_number}R {combination}")
            self.skip_bet(bet_id, "オッズ取得失敗")
            return
        
        # 高い方を選択
        if odds_2t is not None and (odds_2f is None or odds_2t > odds_2f):
            final_odds = odds_2t
            actual_bet_type = 'exacta'
        else:
            final_odds = odds_2f
            actual_bet_type = 'quinella'
    else:
        odds_type_map = {'win': 'win', 'quinella': '2f', 'exacta': '2t'}
        odds_type = odds_type_map.get(bet_type, 'win')
        final_odds = self.get_latest_odds(race_date, stadium_code, race_number, odds_type, combination)
```

### 修正2: オッズ収集の信頼性向上
- 締切5分前まで継続的にオッズを収集するようにする
- 1号艇のオッズが欠損する原因を調査し、修正する
