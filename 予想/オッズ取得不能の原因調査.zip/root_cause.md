# 根本原因の特定 - 2026-01-23

## 問題

ダッシュボードで「締切超過（購入判断未実行）」が表示されているが、
ログでは「期限切れの購入予定はありません」と表示されている。

## 確認事項

### virtual_betsテーブル
- `race_date`: VARCHAR（YYYY-MM-DD形式の文字列）
- `stadium_code`: VARCHAR
- `race_number`: INTEGER

### racesテーブル
- `race_date`: DATE型
- `stadium_code`: INTEGER型
- `race_number`: INTEGER型

## 問題の原因

**型の不一致！**

- `virtual_bets.race_date` は VARCHAR（文字列）
- `races.race_date` は DATE型

JOINで `vb.race_date = r.race_date` を行うと、型が一致しないためJOINが失敗する可能性がある。

## 解決策

JOINの条件で型変換を行う：
```sql
JOIN races r ON vb.race_date::date = r.race_date
    AND CAST(vb.stadium_code AS smallint) = r.stadium_code 
    AND vb.race_number = CAST(r.race_number AS integer)
```

または

```sql
JOIN races r ON vb.race_date = r.race_date::text
    AND CAST(vb.stadium_code AS smallint) = r.stadium_code 
    AND vb.race_number = CAST(r.race_number AS integer)
```
