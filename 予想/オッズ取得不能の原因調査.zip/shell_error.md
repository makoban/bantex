# Render Shell エラー

```
bash: syntax error near unexpected token ')'
```

コマンドの引用符が正しく処理されていない可能性がある。
