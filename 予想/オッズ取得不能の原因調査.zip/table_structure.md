# テーブル構造

## racesテーブル

```sql
CREATE TABLE IF NOT EXISTS races (
    id SERIAL PRIMARY KEY,
    race_date DATE NOT NULL,  -- DATE型
    stadium_code INTEGER NOT NULL,
    race_number INTEGER NOT NULL,
    title VARCHAR(255),
    deadline_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(race_date, stadium_code, race_number)
);
```

## virtual_betsテーブル

```sql
INSERT INTO virtual_bets (
    race_date,  -- VARCHAR型 ('YYYY-MM-DD')
    stadium_code,  -- VARCHAR型
    race_number,  -- INTEGER型
    ...
)
```

## 問題

- races.race_date: DATE型
- virtual_bets.race_date: VARCHAR型 ('YYYY-MM-DD')

`vb.race_date::date = r.race_date` でキャストしているが、これは正しいはず。

## 別の問題を確認

deadline_atの条件を確認：
- `r.deadline_at <= deadline_threshold` (締切が現在+1分以内)
- `r.deadline_at > now_utc` (締切が現在より後)

これは「現在から1分以内に締切を迎えるレース」を取得する条件。

しかし、ダッシュボードを見ると：
- 大村 10R 締切 19:29 → 締切超過
- 大村 12R 締切 20:34 → 締切超過

ログの時刻は 16:29:56 なので、19:29の締切は約3時間後。
「締切1分前」の条件に合致しないため、取得されていない。

**問題は「締切1分前」の条件が厳しすぎること！**
