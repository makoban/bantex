# タイムゾーン分析結果

## 1. 競艇公式サイトからのデータ取得

### collect_odds_mysql.py 231-233行目
```python
deadline = datetime.now().replace(
    hour=hour, minute=minute, second=0, microsecond=0
)
```

**結論**: `datetime.now()`はサーバーのローカル時間（Renderサーバー = UTC）を返す。
- 競艇公式サイトの締切時刻「19:57」をパースすると、`2026-01-24 19:57:00`（タイムゾーンなし）として作成される
- しかし、`datetime.now()`がUTCなので、実際には「UTC 19:57」として解釈される
- **これが問題の根本原因**

## 2. DB保存時

### auto_betting.py get_race_deadlines関数
```python
deadline = target_date.replace(
    hour=hour, minute=minute, second=0, microsecond=0,
    tzinfo=JST  # JSTタイムゾーン付き
)
```

**結論**: JSTタイムゾーン付きで保存している

## 3. 問題の整理

| 処理 | 時間帯 | 問題 |
|------|--------|------|
| 競艇公式サイトの表示 | JST | - |
| collect_odds_mysql.pyでのパース | UTC（サーバー時間） | ✗ 9時間ズレ |
| auto_betting.pyでの保存 | JST（タイムゾーン付き） | ○ |
| DBマイグレーション後 | UTC扱い | ✗ |

## 4. 正しい修正方法

### 方針: 全てJSTで統一

1. **collect_odds_mysql.py**: `datetime.now()` → `datetime.now(JST)` に変更
2. **DB**: TIMESTAMP WITH TIME ZONE のまま
3. **比較**: 全てJSTのaware datetimeで比較
