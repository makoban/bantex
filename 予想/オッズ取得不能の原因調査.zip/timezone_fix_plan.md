# タイムゾーン統一修正計画

## 方針: 全てJSTで統一

### 問題の根本原因

PostgreSQLの`TIMESTAMP WITH TIME ZONE`は、保存時にUTCに変換し、読み出し時にセッションのタイムゾーンで表示する。
Pythonで`datetime.now(JST)`で作成した値をDBに保存すると、UTCに変換されて保存される。
読み出し時に`+00:00`（UTC）として返される。

### 解決策

**DBから読み出した後、JSTに変換する**

```python
# 読み出し後にJSTに変換
if deadline.tzinfo is not None:
    deadline = deadline.astimezone(JST)
```

### 修正が必要なファイル

#### 1. virtual_betting.py
- 308-311行: get_all_pending_bets_near_deadline - deadline_atをJSTに変換
- 679-682行: expire_overdue_bets - deadline_atをJSTに変換

#### 2. virtual_betting_expire.py
- 54-57行: deadline_atをJSTに変換（既に対応済みだが確認）

#### 3. api.py
- 281-284行: deadline_atをJSTに変換（既に対応済みだが確認）
- 726-729行: scheduled_deadlineをJSTに変換（既に対応済みだが確認）

#### 4. auto_betting.py
- 523-526行: expire_overdue_bets - deadline_atをJSTに変換
- 573-577行: process_deadline_bets - scheduled_deadlineをJSTに変換

#### 5. odds_worker.py
- 115行: datetime.now() → datetime.now(JST)に変更
- 182行: datetime.now() → datetime.now(JST)に変更

#### 6. batch_import.py
- 97行: datetime.now() → datetime.now(JST)に変更
- 164-165行: datetime.now() → datetime.now(JST)に変更
- 341-342行: datetime.now() → datetime.now(JST)に変更

#### 7. collect_predictions.py
- 76行: datetime.now() → datetime.now(JST)に変更
- 263行: datetime.now() → datetime.now(JST)に変更
- 581行: datetime.now() → datetime.now(JST)に変更
- 624行: datetime.now() → datetime.now(JST)に変更

#### 8. download_race_data.py
- 229行: datetime.now() → datetime.now(JST)に変更
- 248行: datetime.now() → datetime.now(JST)に変更
- 262行: datetime.now() → datetime.now(JST)に変更

#### 9. download_racer_data.py
- 42-43行: datetime.now() → datetime.now(JST)に変更
- 240-241行: datetime.now() → datetime.now(JST)に変更

#### 10. import_historical_data.py
- 139行: datetime.now() → datetime.now(JST)に変更

#### 11. import_historical_data_parallel.py
- 146行: datetime.now() → datetime.now(JST)に変更

#### 12. imap_client.py
- 36行: datetime.now() → datetime.now(JST)に変更
- 42行: timezone.utc → JSTに変更
- 65行: timezone.utc → JSTに変更

### 重要な修正ポイント

**DBから読み出したdatetimeは必ずJSTに変換する**

```python
# DBから読み出した後
if deadline.tzinfo is not None:
    deadline = deadline.astimezone(JST)
elif deadline.tzinfo is None:
    deadline = deadline.replace(tzinfo=JST)
```
