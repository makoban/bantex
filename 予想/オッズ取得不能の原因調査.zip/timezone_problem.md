# タイムゾーンの問題を発見！

## 現在のコード

```python
now_utc = datetime.now(timezone.utc)
deadline_threshold = now_utc + timedelta(minutes=minutes_to_deadline)

cursor.execute("""
    SELECT vb.*, r.deadline_at
    FROM virtual_bets vb
    JOIN races r ON vb.race_date::date = r.race_date 
        AND CAST(vb.stadium_code AS smallint) = r.stadium_code 
        AND vb.race_number = CAST(r.race_number AS integer)
    WHERE vb.status = 'pending'
    AND r.deadline_at <= %s
    AND r.deadline_at > %s
    ORDER BY r.deadline_at
""", (deadline_threshold, now_utc))
```

## 問題

**deadline_atはJSTで保存されている可能性が高い**

- `now_utc` = UTC時刻（例: 07:29 UTC）
- `deadline_at` = JST時刻（例: 19:29 JST = 10:29 UTC）

比較すると：
- `deadline_at (10:29 UTC) <= deadline_threshold (07:30 UTC)` → False
- `deadline_at (10:29 UTC) > now_utc (07:29 UTC)` → True

条件を満たさないため、取得されない。

## 解決策

1. **deadline_atのタイムゾーンを確認**
2. **now_utcをJSTに変換する**
3. **または、deadline_atをUTCに変換して比較する**

## 確認すべきこと

collector.pyでdeadline_atがどのように保存されているか確認
