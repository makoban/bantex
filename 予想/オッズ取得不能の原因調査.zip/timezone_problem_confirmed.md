# タイムゾーンの問題を確認！

## deadline_atの保存方法

collector.pyで：
```python
deadline = target_date.replace(
    hour=hour, minute=minute, second=0, microsecond=0,
    tzinfo=JST  # ← JSTタイムゾーン付きで保存
)
```

**deadline_atはJSTタイムゾーン付きで保存されている**

## 問題のコード

virtual_betting.pyで：
```python
now_utc = datetime.now(timezone.utc)  # ← UTCで取得
deadline_threshold = now_utc + timedelta(minutes=1)

WHERE r.deadline_at <= %s  # ← UTCと比較
AND r.deadline_at > %s
```

## 問題

PostgreSQLはタイムゾーン付きのTIMESTAMPを比較する際、自動的に変換するはずだが、
`deadline_at`がTIMESTAMP WITHOUT TIME ZONEとして保存されている場合、
JSTの値がそのままUTCとして解釈される。

例：
- deadline_at = 19:29 JST → DBには 19:29 として保存（タイムゾーン情報なし）
- now_utc = 07:29 UTC
- 比較: 19:29 > 07:29 → True（締切は未来）
- 19:29 <= 07:30 → False（締切1分前ではない）

**これが原因で、締切1分前のレースが取得されない！**

## 解決策

JSTで比較する：
```python
from datetime import timezone
JST = timezone(timedelta(hours=9))
now_jst = datetime.now(JST)
deadline_threshold = now_jst + timedelta(minutes=1)
```
