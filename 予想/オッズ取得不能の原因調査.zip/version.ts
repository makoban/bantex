export const APP_VERSION = "8.6";
