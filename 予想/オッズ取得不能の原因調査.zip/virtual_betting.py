"""
仮想購入システム

予想に基づいて仮想的な購入を行い、結果を追跡するシステム
"""

import json
import logging
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional
import psycopg2
from psycopg2.extras import RealDictCursor
import os

# ロガー設定
logger = logging.getLogger(__name__)

# 戦略設定
STRATEGIES = {
    'bias_1_3': {
        'name': '1-3穴バイアス',
        'bet_type': 'quinella',  # 2連複
        'min_odds': 3.0,
        'max_odds': 30.0,
        'base_amount': 1000,
    },
    'bias_1_3_2nd': {
        'name': '1-3穴バイアス2nd',
        'bet_type': 'auto',  # 2連単/2連複を自動選択
        'min_odds': 2.2,
        'max_odds': 30.0,
        'base_amount': 1000,
    },
    '11r12r_win': {
        'name': '11R・12R単勝',
        'bet_type': 'win',  # 単勝
        'min_odds': 1.0,
        'max_odds': 10.0,
        'min_expected_value': 1.0,
        'base_amount': 1000,
    },
    'tansho_kanto': {
        'name': '関東4場単勝',
        'bet_type': 'win',  # 単勝
        'min_odds': 1.5,
        'max_odds': 10.0,
        'min_expected_value': 1.0,
        'base_amount': 1000,
    },
}


class VirtualBettingManager:
    """仮想購入管理クラス"""
    
    def __init__(self, db_url: str = None):
        """
        初期化
        
        Args:
            db_url: PostgreSQL接続URL
        """
        self.db_url = db_url or os.environ.get('DATABASE_URL')
        if not self.db_url:
            raise ValueError("DATABASE_URL is required")
    
    def get_db_connection(self):
        """データベース接続を取得"""
        try:
            conn = psycopg2.connect(self.db_url, cursor_factory=RealDictCursor)
            return conn
        except Exception as e:
            logger.error(f"DB接続エラー: {e}")
            return None
    
    def create_bet(self, race_date: str, stadium_code: str, race_number: int,
                   strategy_type: str, combination: str, bet_type: str,
                   amount: int = 1000, reason: dict = None) -> Optional[int]:
        """
        仮想購入を作成
        
        Args:
            race_date: レース日（YYYY-MM-DD）
            stadium_code: 競艇場コード
            race_number: レース番号
            strategy_type: 戦略タイプ
            combination: 買い目
            bet_type: 購入タイプ（win, quinella, exacta等）
            amount: 購入金額
            reason: 購入理由（JSON）
        
        Returns:
            作成されたbet_id
        """
        conn = self.get_db_connection()
        if not conn:
            return None
        
        try:
            with conn.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO virtual_bets (
                        race_date, stadium_code, race_number, strategy_type,
                        combination, bet_type, amount, status, reason, created_at
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, 'pending', %s, %s)
                    RETURNING id
                """, (
                    race_date, stadium_code, race_number, strategy_type,
                    combination, bet_type, amount,
                    json.dumps(reason) if reason else None,
                    datetime.now(timezone.utc)
                ))
                bet_id = cursor.fetchone()['id']
                conn.commit()
                return bet_id
        except Exception as e:
            logger.error(f"購入作成エラー: {e}")
            conn.rollback()
            return None
        finally:
            conn.close()
    
    def confirm_bet(self, bet_id: int, final_odds: float, reason: dict = None):
        """
        購入を確定
        
        Args:
            bet_id: 購入ID
            final_odds: 確定オッズ
            reason: 確定理由（JSON）
        """
        conn = self.get_db_connection()
        if not conn:
            return
        
        try:
            with conn.cursor() as cursor:
                cursor.execute("""
                    UPDATE virtual_bets 
                    SET status = 'confirmed', 
                        final_odds = %s,
                        reason = %s,
                        confirmed_at = %s,
                        updated_at = %s
                    WHERE id = %s
                """, (
                    final_odds,
                    json.dumps(reason, ensure_ascii=False) if reason else None,
                    datetime.now(timezone.utc),
                    datetime.now(timezone.utc),
                    bet_id
                ))
                conn.commit()
                logger.info(f"購入確定: bet_id={bet_id}, odds={final_odds}")
        except Exception as e:
            logger.error(f"購入確定エラー: {e}")
            conn.rollback()
        finally:
            conn.close()
    
    def skip_bet(self, bet_id: int, reason: str):
        """
        購入を見送り
        
        Args:
            bet_id: 購入ID
            reason: 見送り理由
        """
        conn = self.get_db_connection()
        if not conn:
            return
        
        try:
            with conn.cursor() as cursor:
                # 既存のreasonを取得
                cursor.execute("SELECT reason FROM virtual_bets WHERE id = %s", (bet_id,))
                row = cursor.fetchone()
                existing_reason = {}
                if row and row.get('reason'):
                    try:
                        if isinstance(row['reason'], str):
                            existing_reason = json.loads(row['reason'])
                        elif isinstance(row['reason'], dict):
                            existing_reason = row['reason']
                    except:
                        pass
                
                existing_reason['skipReason'] = reason
                existing_reason['decision'] = 'skipped'
                
                cursor.execute("""
                    UPDATE virtual_bets 
                    SET status = 'skipped', 
                        reason = %s,
                        updated_at = %s
                    WHERE id = %s
                """, (
                    json.dumps(existing_reason, ensure_ascii=False),
                    datetime.now(timezone.utc),
                    bet_id
                ))
                conn.commit()
                logger.info(f"購入見送り: bet_id={bet_id}, reason={reason}")
        except Exception as e:
            logger.error(f"購入見送りエラー: {e}")
            conn.rollback()
        finally:
            conn.close()
    
    def update_result(self, bet_id: int, is_won: bool, payout: int = 0):
        """
        結果を更新
        
        Args:
            bet_id: 購入ID
            is_won: 的中したか
            payout: 払戻金
        """
        conn = self.get_db_connection()
        if not conn:
            return
        
        try:
            with conn.cursor() as cursor:
                status = 'won' if is_won else 'lost'
                cursor.execute("""
                    UPDATE virtual_bets 
                    SET status = %s, 
                        payout = %s,
                        result_confirmed_at = %s,
                        updated_at = %s
                    WHERE id = %s
                """, (
                    status,
                    payout,
                    datetime.now(timezone.utc),
                    datetime.now(timezone.utc),
                    bet_id
                ))
                conn.commit()
                logger.info(f"結果更新: bet_id={bet_id}, status={status}, payout={payout}")
        except Exception as e:
            logger.error(f"結果更新エラー: {e}")
            conn.rollback()
        finally:
            conn.close()
    
    def get_pending_bets(self, race_date: str = None) -> List[Dict]:
        """
        保留中の購入を取得
        
        Args:
            race_date: レース日（指定しない場合は全て）
        
        Returns:
            保留中の購入リスト
        """
        conn = self.get_db_connection()
        if not conn:
            return []
        
        try:
            with conn.cursor() as cursor:
                if race_date:
                    cursor.execute("""
                        SELECT * FROM virtual_bets 
                        WHERE status = 'pending' AND race_date = %s
                        ORDER BY race_number
                    """, (race_date,))
                else:
                    cursor.execute("""
                        SELECT * FROM virtual_bets 
                        WHERE status = 'pending'
                        ORDER BY race_date, race_number
                    """)
                return cursor.fetchall()
        except Exception as e:
            logger.error(f"保留中購入取得エラー: {e}")
            return []
        finally:
            conn.close()
    
    def get_all_pending_bets_near_deadline(self, minutes_to_deadline: int = 1) -> List[Dict]:
        """
        締切間近の保留中購入を取得
        
        Args:
            minutes_to_deadline: 締切までの分数
        
        Returns:
            締切間近の保留中購入リスト
        """
        conn = self.get_db_connection()
        if not conn:
            return []
        
        try:
            with conn.cursor() as cursor:
                # 現在時刻から締切までの時間で絞り込み
                # racesテーブルのdeadline_atを使用
                # JSTタイムゾーンで比較（deadline_atはJSTで保存されている）
                JST = timezone(timedelta(hours=9))
                now_jst = datetime.now(JST)
                deadline_threshold = now_jst + timedelta(minutes=minutes_to_deadline)
                
                # 型の不一致を解消: virtual_bets."stadiumCode"(varchar) vs races.stadium_code(smallint)
                # virtual_betsテーブルはキャメルケースのカラム名を使用
                cursor.execute("""
                    SELECT vb.*, r.deadline_at
                    FROM virtual_bets vb
                    JOIN races r ON vb.race_date::date = r.race_date 
                        AND CAST(vb.stadium_code AS smallint) = r.stadium_code 
                        AND vb.race_number = CAST(r.race_number AS integer)
                    WHERE vb.status = 'pending'
                    AND r.deadline_at <= %s
                    AND r.deadline_at > %s
                    ORDER BY r.deadline_at
                """, (deadline_threshold, now_jst))
                return cursor.fetchall()
        except Exception as e:
            logger.error(f"締切間近購入取得エラー: {e}")
            return []
        finally:
            conn.close()
    
    def get_latest_odds(self, race_date: str, stadium_code: str, race_number: int,
                        odds_type: str, combination: str) -> Optional[float]:
        """
        最新オッズを取得（odds_historyテーブルから）
        
        Args:
            race_date: レース日（YYYYMMDD）
            stadium_code: 競艇場コード
            race_number: レース番号
            odds_type: オッズタイプ（win, 2f, 2t等）
            combination: 買い目（"1", "1=3"等）
        
        Returns:
            オッズ（取得できない場合はNone）
        """
        conn = self.get_db_connection()
        if not conn:
            return None
        
        try:
            with conn.cursor() as cursor:
                # race_dateをYYYY-MM-DD形式に変換
                if len(race_date) == 8:
                    race_date_formatted = f"{race_date[:4]}-{race_date[4:6]}-{race_date[6:8]}"
                else:
                    race_date_formatted = race_date
                
                # オッズタイプはodds_historyではそのまま保存されている
                # win -> win, 2f -> 2f, 2t -> 2t
                db_odds_type = odds_type
                
                # 組み合わせを正規化
                # 単勝: "1" -> "1"
                # 2連複: "1=3" -> "1-3" (odds_historyでは1-3形式で保存)
                normalized_combination = combination.replace('=', '-')
                
                # odds_historyテーブルから最新オッズを取得
                # stadium_codeは文字列（'01', '02'等）で保存されている
                cursor.execute("""
                    SELECT odds_value FROM odds_history
                    WHERE race_date = %s 
                    AND stadium_code = %s 
                    AND race_number = %s
                    AND odds_type = %s
                    AND combination = %s
                    ORDER BY scraped_at DESC
                    LIMIT 1
                """, (race_date_formatted, stadium_code, race_number, db_odds_type, normalized_combination))
                row = cursor.fetchone()
                
                if row and row.get('odds_value') is not None:
                    odds_val = float(row['odds_value'])
                    # 0.0は発売前または投票が少ない状態なので、有効なオッズとして扱わない
                    if odds_val > 0:
                        return odds_val
                
                # 見つからない場合、stadium_codeを2桁にパディングして再試行
                if len(str(stadium_code)) == 1:
                    padded_code = f"0{stadium_code}"
                else:
                    padded_code = str(stadium_code).zfill(2)
                
                cursor.execute("""
                    SELECT odds_value FROM odds_history
                    WHERE race_date = %s 
                    AND stadium_code = %s 
                    AND race_number = %s
                    AND odds_type = %s
                    AND combination = %s
                    ORDER BY scraped_at DESC
                    LIMIT 1
                """, (race_date_formatted, padded_code, race_number, db_odds_type, normalized_combination))
                row = cursor.fetchone()
                
                if row and row.get('odds_value') is not None:
                    odds_val = float(row['odds_value'])
                    if odds_val > 0:
                        return odds_val
                
                return None
        except Exception as e:
            logger.error(f"オッズ取得エラー: {e}")
            return None
        finally:
            conn.close()
    
    def expire_overdue_bets(self):
        """
        締切が過ぎた購入予定を見送り（skipped）に更新する
        """
        logger.info("=== 期限切れ購入予定の処理開始 ===")
        
        conn = self.get_db_connection()
        if not conn:
            return 0
        
        try:
            # JSTタイムゾーンで比較（deadline_atはJSTで保存されている）
            JST = timezone(timedelta(hours=9))
            now_jst = datetime.now(JST)
            
            with conn.cursor() as cursor:
                # 締切が過ぎたpendingの購入予定を取得
                # 型の不一致を解消: virtual_bets.stadium_code(varchar) vs races.stadium_code(smallint)
                cursor.execute("""
                    SELECT vb.id, vb.stadium_code, vb.race_number, vb.reason, r.deadline_at
                    FROM virtual_bets vb
                    JOIN races r ON vb.race_date::date = r.race_date 
                        AND CAST(vb.stadium_code AS smallint) = r.stadium_code 
                        AND vb.race_number = CAST(r.race_number AS integer)
                    WHERE vb.status = 'pending'
                    AND r.deadline_at < %s
                """, (now_jst,))
                expired_bets = cursor.fetchall()
                
                if not expired_bets:
                    logger.info("期限切れの購入予定はありません")
                    return 0
                
                logger.info(f"期限切れの購入予定: {len(expired_bets)}件")
                
                for bet in expired_bets:
                    # 既存のreasonを取得してskipReasonを追加
                    reason = {}
                    if bet.get('reason'):
                        try:
                            if isinstance(bet['reason'], str):
                                reason = json.loads(bet['reason'])
                            elif isinstance(bet['reason'], dict):
                                reason = bet['reason']
                        except:
                            pass
                    
                    reason['skipReason'] = '締切超過（購入判断未実行）'
                    reason['decision'] = 'skipped'
                    
                    cursor.execute("""
                        UPDATE virtual_bets 
                        SET status = 'skipped',
                            reason = %s,
                            updated_at = %s
                        WHERE id = %s
                    """, (json.dumps(reason, ensure_ascii=False), now_jst, bet['id']))
                    
                    logger.info(f"  - bet_id={bet['id']}, {bet['stadium_code']} {bet['race_number']}R, 締切={bet['deadline_at']}")
                    logger.info(f"    -> skippedに更新完了（締切超過）")
                
                conn.commit()
                return len(expired_bets)
                
        except Exception as e:
            logger.error(f"期限切れ処理エラー: {e}")
            if conn:
                conn.rollback()
            return 0
        finally:
            conn.close()
    
    def process_deadline_bets(self):
        """
        締切1分前の購入予定を処理する
        
        - pendingステータスのレースを取得
        - 最新オッズを確認
        - 条件を満たせばconfirmed、満たさなければskipped
        """
        logger.info("=== 締切1分前の購入判断処理開始 ===")
        
        # 締切1分前の購入予定を取得
        pending_bets = self.get_all_pending_bets_near_deadline(minutes_to_deadline=1)
        
        if not pending_bets:
            logger.info("処理対象の購入予定がありません")
            return
        
        logger.info(f"処理対象: {len(pending_bets)}件")
        
        for bet in pending_bets:
            try:
                self._process_single_bet(bet)
            except Exception as e:
                logger.error(f"購入処理エラー: bet_id={bet['id']}, error={e}")
    
    def _process_single_bet(self, bet: Dict):
        """単一の購入予定を処理"""
        bet_id = bet['id']
        strategy_type = bet['strategy_type']
        # virtual_betsテーブルはキャメルケースのカラム名を使用
        race_date = bet['race_date'].strftime('%Y%m%d') if hasattr(bet['race_date'], 'strftime') else str(bet['race_date']).replace('-', '')
        stadium_code = bet['stadium_code']
        race_number = bet['race_number']
        combination = bet['combination']
        bet_type = bet['bet_type']
        
        logger.info(f"処理中: {stadium_code} {race_number}R {combination} ({strategy_type})")
        
        # bet_type='auto'の場合は2連単/2連複の両方を取得して高い方を選択
        if bet_type == 'auto':
            odds_2t = self.get_latest_odds(race_date, stadium_code, race_number, '2t', combination)
            odds_2f = self.get_latest_odds(race_date, stadium_code, race_number, '2f', combination)
            
            logger.info(f"  auto判定: 2連単={odds_2t}, 2連複={odds_2f}")
            
            if odds_2t is None and odds_2f is None:
                logger.warning(f"オッズ取得失敗: {stadium_code} {race_number}R {combination} (2連単/2連複両方なし)")
                self.skip_bet(bet_id, "オッズ取得失敗")
                return
            
            # 高い方を選択（Noneの場合は0として比較）
            odds_2t_val = float(odds_2t) if odds_2t is not None else 0
            odds_2f_val = float(odds_2f) if odds_2f is not None else 0
            
            if odds_2t_val >= odds_2f_val:
                final_odds = odds_2t
                actual_bet_type = 'exacta'  # 2連単
                logger.info(f"  -> 2連単を選択: {final_odds}")
            else:
                final_odds = odds_2f
                actual_bet_type = 'quinella'  # 2連複
                logger.info(f"  -> 2連複を選択: {final_odds}")
        else:
            # 通常のオッズタイプ変換
            odds_type_map = {'win': 'win', 'quinella': '2f', 'exacta': '2t'}
            odds_type = odds_type_map.get(bet_type, 'win')
            
            # 最新オッズを取得
            final_odds = self.get_latest_odds(race_date, stadium_code, race_number, odds_type, combination)
            actual_bet_type = bet_type
        
        if final_odds is None:
            logger.warning(f"オッズ取得失敗: {stadium_code} {race_number}R {combination}")
            self.skip_bet(bet_id, "オッズ取得失敗")
            return
        
        # 戦略設定を取得
        strategy = STRATEGIES.get(strategy_type, {})
        min_odds = strategy.get('min_odds', 1.5)
        max_odds = strategy.get('max_odds', 10.0)
        
        # 購入判断
        reason = {}
        if bet.get('reason'):
            try:
                if isinstance(bet['reason'], str):
                    reason = json.loads(bet['reason'])
                elif isinstance(bet['reason'], dict):
                    reason = bet['reason']
            except:
                pass
        
        reason['finalOdds'] = final_odds
        
        if final_odds < min_odds:
            reason['decision'] = 'skipped'
            reason['skipReason'] = f'オッズが低すぎる ({final_odds} < {min_odds})'
            self.skip_bet(bet_id, reason['skipReason'])
        elif final_odds > max_odds:
            reason['decision'] = 'skipped'
            reason['skipReason'] = f'オッズが高すぎる ({final_odds} > {max_odds})'
            self.skip_bet(bet_id, reason['skipReason'])
        else:
            # 期待値計算（単勝戦略の場合）
            if strategy_type == '11r12r_win':
                # 1号艇の勝率を仮定（実際は過去データから計算）
                estimated_win_rate = 0.5  # 50%と仮定
                expected_value = final_odds * estimated_win_rate
                reason['expectedValue'] = expected_value
                
                if expected_value < strategy.get('min_expected_value', 1.0):
                    reason['decision'] = 'skipped'
                    reason['skipReason'] = f'期待値が低い ({expected_value:.2f} < 1.0)'
                    self.skip_bet(bet_id, reason['skipReason'])
                    return
            
            reason['decision'] = 'confirmed'
            self.confirm_bet(bet_id, final_odds, reason)
    
    def process_results(self):
        """
        確定済みレースの結果を更新する
        
        - confirmedステータスのレースを取得
        - 結果を確認
        - won/lostに更新し、資金を反映
        """
        logger.info("=== 結果更新処理開始 ===")
        
        conn = self.get_db_connection()
        if not conn:
            return
        
        try:
            with conn.cursor() as cursor:
                # 確定済みで結果未確定のレースを取得
                cursor.execute("""
                    SELECT * FROM virtual_bets 
                    WHERE status = 'confirmed'
                    AND result_confirmed_at IS NULL
                """)
                confirmed_bets = cursor.fetchall()
        finally:
            conn.close()
        
        if not confirmed_bets:
            logger.info("結果待ちの購入がありません")
            return
        
        logger.info(f"結果確認対象: {len(confirmed_bets)}件")
        
        for bet in confirmed_bets:
            try:
                self._process_single_result(bet)
            except Exception as e:
                logger.error(f"結果処理エラー: bet_id={bet['id']}, error={e}")
    
    def _process_single_result(self, bet: Dict):
        """単一の結果を処理"""
        bet_id = bet['id']
        race_date = bet['race_date'].strftime('%Y-%m-%d') if hasattr(bet['race_date'], 'strftime') else str(bet['race_date'])
        stadium_code = bet['stadium_code']
        race_number = bet['race_number']
        combination = bet['combination']
        bet_type = bet['bet_type']
        amount = float(bet.get('amount', 1000))
        final_odds = float(bet.get('final_odds', 0) or 0)
        
        logger.info(f"結果確認: {stadium_code} {race_number}R {combination}")
        
        # レース結果を取得
        result = self._get_race_result(race_date, stadium_code, race_number)
        
        if not result:
            logger.info(f"  結果未確定")
            return
        
        # 的中判定
        is_won = self._check_win(combination, bet_type, result)
        
        if is_won:
            # 払戻金を計算
            payout = int(amount * final_odds)
            logger.info(f"  的中！ 払戻金: {payout}円")
        else:
            payout = 0
            logger.info(f"  不的中")
        
        self.update_result(bet_id, is_won, payout)
    
    def _get_race_result(self, race_date: str, stadium_code: str, race_number: int) -> Optional[Dict]:
        """レース結果を取得（racesテーブル経由でrace_idを取得してからrace_resultsを検索）"""
        conn = self.get_db_connection()
        if not conn:
            return None
        
        try:
            with conn.cursor() as cursor:
                # まずracesテーブルからrace_idを取得
                cursor.execute("""
                    SELECT id FROM races
                    WHERE race_date = %s::date
                    AND stadium_code = %s
                    AND race_number = %s
                """, (race_date, stadium_code, race_number))
                race_row = cursor.fetchone()
                
                if not race_row:
                    logger.debug(f"レースが見つかりません: {race_date} {stadium_code} {race_number}R")
                    return None
                
                race_id = race_row['id']
                
                # race_resultsテーブルから結果を取得
                cursor.execute("""
                    SELECT * FROM race_results
                    WHERE race_id = %s
                """, (race_id,))
                return cursor.fetchone()
        except Exception as e:
            logger.error(f"結果取得エラー: {e}")
            return None
        finally:
            conn.close()
    
    def _check_win(self, combination: str, bet_type: str, result: Dict) -> bool:
        """的中判定"""
        if not result:
            return False
        
        # 結果の着順を取得
        first = str(result.get('first_place', ''))
        second = str(result.get('second_place', ''))
        third = str(result.get('third_place', ''))
        
        if bet_type == 'win':
            # 単勝: 1着が一致
            return combination == first
        elif bet_type == 'quinella':
            # 2連複: 1-2着の組み合わせ（順不同）
            combo_set = set(combination.replace('=', '-').split('-'))
            result_set = {first, second}
            return combo_set == result_set
        elif bet_type == 'exacta':
            # 2連単: 1-2着の順番が一致
            combo_parts = combination.replace('=', '-').split('-')
            return combo_parts[0] == first and combo_parts[1] == second
        
        return False
    
    def get_summary(self, race_date: str = None) -> Dict:
        """
        購入サマリーを取得
        
        Args:
            race_date: レース日（指定しない場合は全期間）
        
        Returns:
            サマリー情報
        """
        conn = self.get_db_connection()
        if not conn:
            return {}
        
        try:
            with conn.cursor() as cursor:
                if race_date:
                    cursor.execute("""
                        SELECT 
                            COUNT(*) as total,
                            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                            SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
                            SUM(CASE WHEN status = 'won' THEN 1 ELSE 0 END) as won,
                            SUM(CASE WHEN status = 'lost' THEN 1 ELSE 0 END) as lost,
                            SUM(CASE WHEN status = 'skipped' THEN 1 ELSE 0 END) as skipped,
                            SUM(CASE WHEN status IN ('confirmed', 'won', 'lost') THEN amount ELSE 0 END) as total_bet,
                            SUM(CASE WHEN status = 'won' THEN payout ELSE 0 END) as total_payout
                        FROM virtual_bets
                        WHERE race_date = %s
                    """, (race_date,))
                else:
                    cursor.execute("""
                        SELECT 
                            COUNT(*) as total,
                            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                            SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
                            SUM(CASE WHEN status = 'won' THEN 1 ELSE 0 END) as won,
                            SUM(CASE WHEN status = 'lost' THEN 1 ELSE 0 END) as lost,
                            SUM(CASE WHEN status = 'skipped' THEN 1 ELSE 0 END) as skipped,
                            SUM(CASE WHEN status IN ('confirmed', 'won', 'lost') THEN amount ELSE 0 END) as total_bet,
                            SUM(CASE WHEN status = 'won' THEN payout ELSE 0 END) as total_payout
                        FROM virtual_bets
                    """)
                
                row = cursor.fetchone()
                
                total_bet = row['total_bet'] or 0
                total_payout = row['total_payout'] or 0
                
                return {
                    'total': row['total'] or 0,
                    'pending': row['pending'] or 0,
                    'confirmed': row['confirmed'] or 0,
                    'won': row['won'] or 0,
                    'lost': row['lost'] or 0,
                    'skipped': row['skipped'] or 0,
                    'total_bet': total_bet,
                    'total_payout': total_payout,
                    'profit': total_payout - total_bet,
                    'roi': (total_payout / total_bet * 100) if total_bet > 0 else 0
                }
        except Exception as e:
            logger.error(f"サマリー取得エラー: {e}")
            return {}
        finally:
            conn.close()


# モジュールレベルの関数（odds_worker.pyから呼び出される）
def process_virtual_betting():
    """
    仮想購入処理のエントリポイント
    odds_worker.pyから30秒ごとに呼び出される
    
    処理内容:
    1. 締切1分前のレースの購入判断を実行
    2. 締切超過のレースを見送りに更新
    3. 確定済みレースの結果を更新
    """
    database_url = os.environ.get('DATABASE_URL')
    if not database_url:
        logger.warning("DATABASE_URL環境変数が設定されていません")
        return
    
    try:
        manager = VirtualBettingManager(database_url)
        
        # 締切1分前のレースの購入判断を実行
        manager.process_deadline_bets()
        
        # 締切超過のレースを見送りに更新
        expired_count = manager.expire_overdue_bets()
        if expired_count > 0:
            logger.info(f"締切超過で見送りにしたレース: {expired_count}件")
        
        # 確定済みレースの結果を更新
        manager.process_results()
        
    except Exception as e:
        logger.error(f"仮想購入処理エラー: {e}")
        import traceback
        traceback.print_exc()
